data.raw.roboport.roboport.energy_source.input_flow_limit = "200MW"
data.raw.roboport.roboport.energy_source.buffer_capacity = "800MJ"
data.raw.roboport.roboport.charging_energy = "20MW"
data.raw.roboport.roboport.charging_offsets =
    {
      {-2.5, -1.5}, {2.5, -1.5}, {2.5, 2.5}, {-2.5, 2.5}
    }
